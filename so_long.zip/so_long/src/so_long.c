/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wchow <wchow@42mail.sutd.edu.sg>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/17 15:57:21 by wchow             #+#    #+#             */
/*   Updated: 2024/05/14 19:53:58 by wchow            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

typedef struct s_data
{
	void	*img;
	char	*addr;
	int	bits_per_pixel;
	int	line_length;
	int	endian;
}		t_data;

typedef struct s_vars
{
	void	*mlx;
	void	*win;
}	t_vars;

int	key_hook(int keycode, t_vars *vars)
{
	printf("key pressed\n");
	printf("keycode: 0x%02x\n", keycode);
	if (keycode == XK_Escape)
	{
		mlx_destroy_window(vars->mlx, vars->win);
		printf("Escape pressed. Shutting down.\n");
		exit (1);
	}
	if (keycode == XK_w || keycode == XK_a || keycode == XK_s
		|| keycode == XK_d)
		printf("wasd pressed. \n");
	return (0);
}

int	exit_button(t_vars *vars)
{
	mlx_destroy_window(vars->mlx, vars->win);
	printf("Exit cross pressed. Shutting down.\n");
	exit(0);
}

void	ft_mlx_pixel_put(t_data *data, int x, int y, int color)
{
	char	*dst;
	
	dst = data->addr + (y * data->line_length + x * (data->bits_per_pixel / 8));
	*(unsigned int*)dst = color;
}

char	**parse_map(char *arg)
{
	//check validity of map then push the map into 2D array.
	//Proceed to process graphical management and textures based on the map
	int	fd;
	char	*line;
	char	**result;
	int	i;

	i = 0;
	result = malloc(sizeof(char *) * 1024);
	fd = open(arg, O_RDONLY);
	while (1)
	{
		line = get_next_line(fd);
		if (!line)
			break ;
		result[i] = malloc(sizeof(char) * (ft_strlen(line)) + 1);
		ft_strlcpy(result[i], line, ft_strlen(line) + 1);
		free (line);
		i++;
	}
	result[i] = NULL;
	return (result);
}



int	main(int argc, char **argv)
{
	char	**map;
	if (argc != 2)
	{
		printf("Error.\nYou can only input 2 arguments\n");
		return (0);
	}
	map = parse_map(argv[1]);
	if (!check_map_validity(map))
	{
		free (map);
		return (69);
	}


		
	t_data	img;
	t_vars	vars;
	
	int	x = 5;
	int	y = 100;
	
	vars.mlx = mlx_init();
	vars.win = mlx_new_window(vars.mlx, 640, 480, "Hello World!");
	img.img = mlx_new_image(vars.mlx, 640, 480);
	img.addr = mlx_get_data_addr(img.img, &img.bits_per_pixel, &img.line_length, &img.endian);

	while (y <= 300)
	{
		x = 5;
		while (x <= 450)
		{
			ft_mlx_pixel_put(&img, x, y, 0x0000FFFF);
			x++;
		}
		y++;
	}
	
	mlx_put_image_to_window(vars.mlx, vars.win, img.img, 0, 0);
	mlx_key_hook(vars.win, key_hook, &vars);
	mlx_hook(vars.win, 17, 1L << 17, exit_button, &vars);
	mlx_loop(vars.mlx);
}
