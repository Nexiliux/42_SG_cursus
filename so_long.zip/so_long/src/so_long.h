/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wchow <wchow@42mail.sutd.edu.sg>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/14 13:45:52 by wchow             #+#    #+#             */
/*   Updated: 2024/05/14 16:53:16 by wchow            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <X11/keysym.h>
#include "../mlx_linux/mlx.h"
#include "get_next_line.h"
#include "../libft/libft.h"
#include "../printf/includes/ft_printf.h"

//Error Checking
int	check_map_validity(char **map);
int	check_walls(char **map, int i, int j);
int	check_elements(char **map);
int	check_amounts(char **map, int p, int e, int c);
int	check_structure(char **map);

#endif