/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_validity.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wchow <wchow@42mail.sutd.edu.sg>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/14 15:46:08 by wchow             #+#    #+#             */
/*   Updated: 2024/05/14 18:41:44 by wchow            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	check_structure(char **map)
{
    int	i;
	size_t	count;

	i = 0;
	while (map[i])
	{
		count = ft_strlen(map[i]);
		if (map[i + 1] && count != ft_strlen(map[i + 1]))
		{
			printf("Error.\nInvalid map structure. Make sure it's a rectangle\n");
			return (0);
		}
        i++;
	}
	return (1);
}

int	check_amounts(char **map, int p, int e, int c)
{
	int	i;
	int	j;

	i = -1;
	while(map[++i])
	{
		j = -1;
		while(map[i][++j])
		{
			if (map[i][j] == 'P')
				p++;
			if (map[i][j] == 'E')
				e++;
			if (map[i][j] == 'C')
				c++;
		}
	}
	if (p != 1 || e != 1 || c < 1)
		return (0);
	return (1);
}

int	check_elements(char **map)
{
	int	i;
	int	j;

	i = -1;
	while(map[++i])
	{
		j = -1;
		while(map[i][j])
		{
			if (map[i][j] == 'P' || map[i][j] == 'E' || map[i][j] == 'C'
				|| map[i][j] == '1' || map[i][j] == '0')
				j++;
			else
			{
				printf("Error.\nUse only 1, 0, P, C and E.\n");
				return (0);
			}
		}
	}
	return (1);
}

int	check_walls(char **map, int i, int j)
{
	int	row_len;

	while (map[0][j] && map[i][j] != '\n')
	{
		if (map[0][j] != '1')
			return (0);
		j++;
	}
	row_len = j - 1;
	while(map[i + 1])
	{
		if (map[i][0] != '1' || map[i][row_len] != '1')
			return (0);
		i++;
	}
	j = 0;
	while (map[i][j] && map[i][j] != '\n')
	{
		if (map[i][j] && map[i][j] != '1')
			return (0);
		j++;
	}
	return (1);
}

int	check_map_validity(char **map)
{
	if (!check_structure(map))
		return (0);
	if (!check_amounts(map, 0, 0, 0))
	{
		printf("Error.\nInvalid amounts of player/element/collectibles.\n");
		return (0);
	}
	if (!check_elements(map))
		return (0);
	if (!check_walls(map, 1, 0))
	{
		printf("Error.\nMake sure surrounding walls are 1s.\n");
		return (0);
	}
	return (1);
}
